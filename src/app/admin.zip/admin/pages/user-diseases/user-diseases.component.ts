import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-diseases',
  templateUrl: './user-diseases.component.html',
  styleUrls: ['./user-diseases.component.scss']
})
export class UserDiseasesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
