import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
import { DashboardService } from '../../services/dashboard.service';

@Component({
  selector: 'app-manufacturers',
  templateUrl: './agri-manufacturers.component.html',
  styleUrls: ['./agri-manufacturers.component.scss']
})
export class ManufacturersComponent implements OnInit, AfterViewInit {
  buttons: TableBtn[] | any;

  dataUsers: any;
  columnsUsers: TableColumn | any;
  totalRides: number = 0;
  footer: string = '';
  totalVolume: number = 0;
  fillerNav: string[] | any;
  products: any[] = [
    { value: 'Seeds', viewValue: 'Seeds' },
    { value: 'Truck', viewValue: 'Truck' },
    { value: 'Urea', viewValue: 'Urea' },
  ];
  isTable: boolean = false;

  constructor(

    private dashboardService: DashboardService,

  ) { }
  ngAfterViewInit(): void {
    this.dashboardService.get('mfr').subscribe({
      error: (err: any) => { },
      next: (data: any) => {
        console.log('-----------', data)
        this.dataUsers = data;
        this.columnsUsers = [
          { columnDef: 'id', header: 'ID', cell: (element: any) => `${element.id}` },
          { columnDef: 'name', header: 'Name', cell: (element: any) => `${element.name}` },
          { columnDef: 'company_name', header: 'company_name', cell: (element: any) => `${element.company_name}` },
          { columnDef: 'address', header: 'address', cell: (element: any) => `${element.address}` },
          { columnDef: 'city', header: 'city', cell: (element: any) => `${element.city}` },
          {columnDef: 'phone', header: 'phone', cell: (element: any) => `${element.phone}`},
          {columnDef: 'alt_phone', header: 'alt_phone', cell: (element: any) => `${element.alt_phone}`},
          {columnDef: 'email', header: 'email', cell: (element: any) => `${element.email}`},
          {columnDef: 'gst_no', header: 'gst_no', cell: (element: any) => `${element.gst_no}`}
        ]
        this.isTable = true;
      },
    });
  }

  ngOnInit(): void {
    this.buttons = [
      { styleClass: 'btn-success', icon: 'delete', payload: (element: UserData) => `${element.id}`, action: 'add' },
      { styleClass: 'btn-primary', icon: 'edit', payload: (element: UserData) => `${element.id}`, action: 'edit' },
    ];

    

    // this.dataUsers = [
    //   { name: 'Naresh', company_name: 'Naresh123', 'password': 'DSF*&*AS898', 'role': 'Staff' },
    //   { name: 'Nageswararao', user_name: 'Nageswararao123', 'password': 'DSF*&*AS898', 'role': 'Admin' },
    //   { name: 'Vittal', user_name: 'Vittal123', 'password': 'VittalDSF*&*AS898', 'role': 'SuperAdmin' },
    // ];


  //   {
  //     "id": 1,
  //     "name": "Revathi1",
  //     "company_name": "Cinderella",
  //     "address": "205/3rt, Saidabad",
  //     "city": "Hyderabad",
  //     "phone": "9553196591",
  //     "alt_phone": "9666189600",
  //     "email": "muthyala19@gmail.com",
  //     "gst_no": ""
  // }
    //api
    
  }
  buttonClick(e: any) { }
}

export interface UserData {
  id: string;
  name: string;
  date: Date;
  rides: number;
  volume?: string;
  material: string;
}
export interface TableColumn {
  columnDef: string;
  header: string;
  cell: (arg0: any) => string;
}
export interface TableBtn {
  styleClass: string;
  icon: string;
  payload: (arg0: any) => string;
  action: string;
}

