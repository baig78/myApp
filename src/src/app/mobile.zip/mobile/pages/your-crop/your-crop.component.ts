import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-crop',
  templateUrl: './your-crop.component.html',
  styleUrls: ['./your-crop.component.scss']
})
export class YourCropComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
