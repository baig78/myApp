import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dukaan',
  templateUrl: './dukaan.component.html',
  styleUrls: ['./dukaan.component.scss']
})
export class DukaanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
